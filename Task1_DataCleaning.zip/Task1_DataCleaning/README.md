# Task 1: Data Cleaning and Preprocessing

## Dataset
**Mall Customer Segmentation (Sample)**

## Steps Performed
1. Removed duplicate records.
2. Filled missing Customer IDs and Ages using forward fill and median respectively.
3. Standardized 'Gender' values (male/female/unknown).
4. Filled missing income and spending score values with median/mean.
5. Converted date formats to `dd-mm-yyyy`.
6. Renamed columns to be lowercase and underscore-separated.
7. Checked and fixed data types.

## Deliverables
- `raw_data.csv`: Original dataset (with nulls, duplicates, inconsistent formats).
- `cleaned_data.csv`: Final cleaned dataset.
- `data_cleaning.ipynb`: Python code used.
- `README.md`: Summary of steps and learning outcomes.

## Tools Used
- Python
- Pandas Library

---
**By completing this task, you demonstrate skills in:**
- Handling missing values and duplicates
- Data standardization and formatting
- Preparing datasets for analysis
